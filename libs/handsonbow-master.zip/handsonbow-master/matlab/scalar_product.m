function sim = scalar_product(x,y)
    sim=x*y';
end